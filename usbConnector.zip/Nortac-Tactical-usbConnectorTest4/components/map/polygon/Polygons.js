import React from 'react';
import {
  StyleSheet,
  View,
} from 'react-native';
import {
  Polygon,
} from 'react-native-maps';
import {useDispatch, useSelector} from 'react-redux';

import {setDescriptionInfo} from '@reducers/mapReducer';


export default function Polygons() {

  const dispatch = useDispatch();

  const polygons = useSelector(state => state.polygon.polygons)

  return (
    <>
      {polygons.map((polygon, index) => (
        <Polygon
          key={index}
          coordinates={polygon.coordinates}
          strokeColor="#000"
          fillColor="rgba(255,0,0,0.5)"
          strokeWidth={1}
          zIndex={11}
          tappable={true}
          name={polygon.name}
          holes={polygon.holes || []}
          onPress={data => {
            dispatch(setDescriptionInfo(polygon.description))
          }}
        />
      ))}
    </>
  );
}

//create our styling code:
const styles = StyleSheet.create({
 
});
